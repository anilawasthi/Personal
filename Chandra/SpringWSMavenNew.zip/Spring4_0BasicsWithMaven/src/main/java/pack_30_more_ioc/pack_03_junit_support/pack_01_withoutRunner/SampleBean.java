package pack_30_more_ioc.pack_03_junit_support.pack_01_withoutRunner;

public class SampleBean {

	public String sampleMethod() {
		return ("Sample method");
	}
}
