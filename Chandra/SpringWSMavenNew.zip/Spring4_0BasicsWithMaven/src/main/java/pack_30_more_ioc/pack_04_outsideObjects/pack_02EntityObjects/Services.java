package pack_30_more_ioc.pack_04_outsideObjects.pack_02EntityObjects;

public class Services {
	
	public void service1(int empNo){
		System.out.println("Service on "+empNo);
	}
}
