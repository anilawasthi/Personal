package pack_40_aop.pack_10_aspect.pack_joinpoints.pack_buss;

public interface BusinessInterface {

	public String someBusinessMethod();
	
	public void methodThrowingException() throws BusinessException;
}
