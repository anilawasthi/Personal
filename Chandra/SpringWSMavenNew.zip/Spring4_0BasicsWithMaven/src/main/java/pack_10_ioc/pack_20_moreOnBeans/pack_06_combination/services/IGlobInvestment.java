package pack_10_ioc.pack_20_moreOnBeans.pack_06_combination.services;

public interface IGlobInvestment {
	public String getFirmName();
}
