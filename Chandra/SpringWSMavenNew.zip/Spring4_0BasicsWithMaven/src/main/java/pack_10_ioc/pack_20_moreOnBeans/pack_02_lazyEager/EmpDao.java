package pack_10_ioc.pack_20_moreOnBeans.pack_02_lazyEager;

public class EmpDao {

	public EmpDao(){
		System.out.println("Constructor of EmpDao: "+this.hashCode());
	}
}
