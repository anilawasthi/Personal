package pack_10_ioc.pack_70_namespace.pack_05_combine.withXml.pack020_1por_multiObj;

public class ServiceA {
	private String value1; 
	private String value2; 
	
	
	public ServiceA(){
		
	}
	
	public void setValue1(String value1) {
		this.value1 = value1;
	}
	public void setValue2(String value2) {
		this.value2 = value2;
	}

	@Override
	public String toString() {
		return "ServiceA [value1=" + value1 + ", value2=" + value2 + "]";
	}	
}
